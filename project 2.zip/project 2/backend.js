function saklar() {
    console.log("Saklar function executed");
    let lampu = document.getElementById("lampu");
    console.log(lampu);
    if (lampu.src.match("off")) {
        lampu.src = "assets/on.gif";
    } else {
        lampu.src = "assets/off.gif";
    }
    // logika nya jika lampu menyala maka matikan dan sebaliknya, id lampu di baca off 
}


